# Copyright 2026 Peter Cheng
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
claw-mem Memory Links and Tags

Simple markdown-based linking and tagging system.

Syntax:
- Links: [[memory_id]] or [[2026-03-25#投资决策]]
- Tags: #tag or #标签名
"""

from .memory_links import (
    MemoryLink,
    MemoryTags,
    MemoryLinkParser,
    MemoryTagParser,
    MemoryLinkManager
)

__all__ = [
    "MemoryLink",
    "MemoryTags",
    "MemoryLinkParser",
    "MemoryTagParser",
    "MemoryLinkManager"
]
